package com.online.bookstore.FreeLib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreeLibApplicationTests {

	@Test
	void contextLoads() {
	}

}
