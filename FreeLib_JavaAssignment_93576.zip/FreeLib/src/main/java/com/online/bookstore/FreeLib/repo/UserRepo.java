package com.online.bookstore.FreeLib.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.online.bookstore.FreeLib.model.User;

public interface UserRepo extends JpaRepository<User, String>{
	@Query("SELECT u FROM User u WHERE u.email = ?1")
    public User findByEmail(String email);

	@Query("SELECT role FROM User WHERE username = ?1")
	public String getUserRole(String userName);

}
