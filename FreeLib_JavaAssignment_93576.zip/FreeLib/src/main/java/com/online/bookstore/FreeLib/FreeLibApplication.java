package com.online.bookstore.FreeLib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//(exclude = {SecurityAutoConfiguration.class })
@SpringBootApplication
public class FreeLibApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreeLibApplication.class, args);
	}

}
