package com.online.bookstore.FreeLib.model;

import javax.persistence.*;


@Entity
public class Book {
	
	@Id
	@GeneratedValue
	private long bookId;
	@Column(updatable=false, nullable=false)
	private String name, author;
	private float price;
	private int availableUnits;
	
	public Book() {
		super();
	}
	
	public Book(long bookId, String name, String author, float price, int availableUnits) {
		super();
		this.bookId = bookId;
		this.name = name;
		this.author = author;
		this.price = price;
		this.availableUnits = availableUnits;
	}
	
	

	public long getBookId() {
		return bookId;
	}
	

	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getAvailableUnits() {
		return availableUnits;
	}
	public void setAvailableUnits(int availableUnits) {
		this.availableUnits = availableUnits;
	}
	
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", name=" + name + ", author=" + author + ", price=" + price
				+ ", availableUnits=" + availableUnits + "]";
	}
	

}
