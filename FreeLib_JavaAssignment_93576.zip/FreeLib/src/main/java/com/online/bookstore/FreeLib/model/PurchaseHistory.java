package com.online.bookstore.FreeLib.model;

import javax.persistence.*;

@Entity
public class PurchaseHistory {
	
	@Id
	private String transactionId;
	
	private String user;
	private long bookId;
	private String book_name;
	private long amount_charged;
	private int quantity;
	
	public PurchaseHistory() {
		super();
	}
	
	

	public PurchaseHistory(String transactionId, String user, long bookId, String book_name, long amount_charged,
			int quantity) {
		super();
		this.transactionId = transactionId;
		this.user = user;
		this.bookId = bookId;
		this.book_name = book_name;
		this.amount_charged = amount_charged;
		this.quantity = quantity;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public String getBook_name() {
		return book_name;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public long getAmount_charged() {
		return amount_charged;
	}

	public void setAmount_charged(long amount_charged) {
		this.amount_charged = amount_charged;
	}

	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public long getBookId() {
		return bookId;
	}
	public void setBookId(long bookId) {
		this.bookId = bookId;
	}
	
	

}
