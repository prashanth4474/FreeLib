package com.online.bookstore.FreeLib.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.online.bookstore.FreeLib.model.User;
import com.online.bookstore.FreeLib.repo.UserRepo;

@Service
public class UserServices {
	private final UserRepo userRepo;
	 Logger logger = LoggerFactory.getLogger(UserServices.class);

	@Autowired
	public UserServices(UserRepo userRepo) {
		super();
		this.userRepo = userRepo;
	}
	
	public User addUser(User user) {
		user.encodedPwd();
		return userRepo.save(user);
	}
	
	public boolean checkIsAdmin() {
		String userName = this.getLoggedInUserName();
		String role = userRepo.getUserRole(userName);
		return role.equals("user") ? false : true;
//		logger.info("Prashanth:"+ role+":"+role.length()+":" +isAdmin);
//		return isAdmin;
	}
	
	public String getLoggedInUserName() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = "";

		if (principal instanceof UserDetails) {
		  username = ((UserDetails)principal).getUsername();
		} else {
		  username = principal.toString();
		}
		return username;
	}
	
	
	

}