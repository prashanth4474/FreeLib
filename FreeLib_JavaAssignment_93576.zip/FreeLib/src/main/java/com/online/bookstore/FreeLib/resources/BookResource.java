package com.online.bookstore.FreeLib.resources;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.online.bookstore.FreeLib.model.Book;
import com.online.bookstore.FreeLib.model.PurchaseHistory;
import com.online.bookstore.FreeLib.model.User;
import com.online.bookstore.FreeLib.service.BookServices;
import com.online.bookstore.FreeLib.service.PurchaseHistoryServices;
import com.online.bookstore.FreeLib.service.UserServices;

@RestController
@RequestMapping("/freelib") 
public class BookResource {

	private final BookServices bookServ;
	private final UserServices userServ;
	private final PurchaseHistoryServices historyService;

	@Autowired
	public BookResource( BookServices bookServ, UserServices userServ,
			PurchaseHistoryServices historyService) {
		super();
		this.bookServ = bookServ;
		this.userServ = userServ;
		this.historyService = historyService;
	}

//	@GetMapping("/username")
//	public String currentUserName(Principal principal) {
//		return principal.getName();
//	}
	@GetMapping("/add-user-form")
	public ModelAndView addUserForm() {
		ModelAndView model = new ModelAndView();
		model.addObject("user", new User());
		model.setViewName("add_user");
		return model;
	}
	
	

	@PostMapping("/register-user")
	public ModelAndView registerUser(@ModelAttribute User user){
		user.setEnabled(1);
		user.setRole("user");
		userServ.addUser(user);
		return new ModelAndView("user_created");
	}
	
	
	@GetMapping("/add-book-form")
	public ModelAndView addBookForm() {
		ModelAndView model = new ModelAndView();
		model.addObject("book", new Book());
		model.setViewName("add_book");
		return model;
	}
	
	@PostMapping("/add-book")
	public ModelAndView addBook(@ModelAttribute Book book) {
		bookServ.addBook(book);
		ModelAndView model = new ModelAndView("book_created");
		model.addObject("msg","'"+ book.getName() + "' book has been saved successfully!!");
		return model;
	}

	@GetMapping("/all-books")
	public ModelAndView getAllBooks() {
		ModelAndView model = new ModelAndView();
//		String uri = "http://localhost:8080/freelib/username";
//		RestTemplate restTemp = new RestTemplate();
//		String loggedInUser = restTemp.getForObject(uri, String.class);
		model.addObject("isAdmin", userServ.checkIsAdmin());
		model.addObject("books", bookServ.getAvailableBooks());
		model.setViewName("all_books");
		return model;
	}
	
	@GetMapping("/delete-book/{id}")
	public ModelAndView deleteBook(@PathVariable("id") long id) {
		bookServ.deleteBook(id);
		ModelAndView model = new ModelAndView();
		model.setViewName("deleted");
		return model;

	}
	
	@GetMapping("/update-book-form/{id}")
	public ModelAndView updateBookForm(@PathVariable("id") long id) {
		Book book = bookServ.getBookById(id);
		ModelAndView model = new ModelAndView();
		model.addObject("book", book);
		model.setViewName("add_book");
		return model;
	}
	
	
	
	@PostMapping("/update-book")
	public ModelAndView updateBook(@ModelAttribute Book book) {
		bookServ.addBook(book);
		ModelAndView model = new ModelAndView("book_created");
		model.addObject("msg","'"+ book.getName() + "' book has been saved successfully!!");
		return model;
	}
	
	
	
	@GetMapping("/buy-book-form/{id}")
	public ModelAndView buyBookForm(@PathVariable("id") long id) {
		Book book = bookServ.getBookById(id);
		ModelAndView model = new ModelAndView();
		PurchaseHistory purchase = new PurchaseHistory();
		purchase.setBookId(book.getBookId());
		purchase.setBook_name(book.getName());
		purchase.setUser(userServ.getLoggedInUserName());
		model.addObject("transaction", purchase);
		model.addObject("availableUnit", book.getAvailableUnits());
		model.addObject("price", book.getPrice());
		model.setViewName("buy_book");
		return model;
	}
	

	@PostMapping("/buy")
	public ModelAndView buyeBook(@ModelAttribute PurchaseHistory purchase) {
		historyService.buy(purchase);
		Book book = bookServ.getBookById(purchase.getBookId());
		book.setAvailableUnits(book.getAvailableUnits()-1);
		bookServ.addBook(book);
		
		ModelAndView model = new ModelAndView("book_created");
		model.addObject("msg","You have bought '"+ purchase.getBook_name() + "', have a good read!"
				+ "\n please refer Purchase Transaction Id: "+ purchase.getTransactionId());
		return model;
	}
	
	@GetMapping("/my-purchases")
	public ModelAndView getAllHistory(){
		
		ModelAndView model = new ModelAndView("list_transactions");
		model.addObject("transactions", historyService.getMyPurchases(userServ.getLoggedInUserName()));
		return model;
	}
	
	@GetMapping("/get-receipt/{id}")
	public ResponseEntity<PurchaseHistory> getReceipt(@PathVariable("id") String id){
		return new ResponseEntity<PurchaseHistory>(historyService.getReceipt(id), HttpStatus.OK);
	}
	
	@PostMapping("/buy-re")
	public ResponseEntity<PurchaseHistory> buyRe(@RequestBody PurchaseHistory purchase){
		return new ResponseEntity<PurchaseHistory>(historyService.buy(purchase), HttpStatus.CREATED);
	}
	
	@PostMapping("/add-book-re")
	public ResponseEntity<Book> addBookRe(@RequestBody Book book) {
		Book newBook = bookServ.addBook(book);
		return new ResponseEntity<Book>(newBook, HttpStatus.CREATED);
	}

	@GetMapping("/all-books-re")
	public ResponseEntity<List<Book>> getAllBooksRE() {
		List<Book> books = bookServ.getAllBooks();
		return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
	}

	@GetMapping("/available-books")
	public ResponseEntity<List<Book>> getAvailableBooks() {
		List<Book> books = bookServ.getAvailableBooks();
		return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
	}
	

	@DeleteMapping("/delete-book-re/{id}")
	public ResponseEntity<String> deleteBookRe(@PathVariable("id") long id) {
		bookServ.deleteBook(id);
		return new ResponseEntity<>("Book '" + id + "' has been deleted.", HttpStatus.OK);

	}
	
	@PostMapping("/register")
	public ResponseEntity<User> signUp(@RequestBody User user){
		return new ResponseEntity<User>(userServ.addUser(user), HttpStatus.CREATED);
	}
	

//	@PatchMapping("/update-book")
//	public ResponseEntity<Book> updateBook(@RequestBody Book book) {
//		Book updatedBook = bookServ.updateBook(book);
//		return new ResponseEntity<Book>(updatedBook, HttpStatus.OK);
//
//	}

}
