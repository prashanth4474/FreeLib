package com.online.bookstore.FreeLib.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;

import com.online.bookstore.FreeLib.BookNotFoundException;
import com.online.bookstore.FreeLib.model.Book;
import com.online.bookstore.FreeLib.repo.*;

@Service
public class BookServices {
	private final BooksRepo booksRepo;

	@Autowired
	public BookServices(BooksRepo booksRepo) {
		super();
		this.booksRepo = booksRepo;
	}
	
	public List<Book> getAllBooks(){
		return booksRepo.findAll();
	}
	
	public List<Book> getAvailableBooks(){
		return booksRepo.getAvailableBooks();
	}
	
	public Book addBook(Book book) {
		return booksRepo.save(book);
	}
	
	public void deleteBook(long id) {
		 booksRepo.deleteById(id);
	}

	public Book updateBook(Book book) {
		return booksRepo.save(book);
		
	}

	public Book getBookById(long bookId) {
		
		return booksRepo.findById(bookId).get();
	}
	
	

}
