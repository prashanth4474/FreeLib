package com.online.bookstore.FreeLib.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.online.bookstore.FreeLib.model.PurchaseHistory;

@Repository
public interface PurchaseRepo extends JpaRepository<PurchaseHistory, String> {

	@Query("FROM PurchaseHistory WHERE user=?1")
	List<PurchaseHistory> getMyPurchases(String userName);
}
