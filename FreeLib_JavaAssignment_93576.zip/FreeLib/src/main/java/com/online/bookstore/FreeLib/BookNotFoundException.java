package com.online.bookstore.FreeLib;

public class BookNotFoundException extends RuntimeException{

	public BookNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
