package com.online.bookstore.FreeLib.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.bookstore.FreeLib.repo.PurchaseRepo;
import com.online.bookstore.FreeLib.BookNotFoundException;
import com.online.bookstore.FreeLib.model.PurchaseHistory;

@Service
public class PurchaseHistoryServices {
	
	private final PurchaseRepo purchaseRepo;

	@Autowired
	public PurchaseHistoryServices(PurchaseRepo purchaseRepo) {
		super();
		this.purchaseRepo = purchaseRepo;
	}
	
	public List<PurchaseHistory> getMyPurchases(String userName){
		return purchaseRepo.getMyPurchases(userName);
	}
	
	public List<PurchaseHistory> getAllPurchases(){
		return purchaseRepo.findAll();
	}

	public PurchaseHistory buy(PurchaseHistory purchase) {
		// TODO Auto-generated method stub
		purchase.setTransactionId(UUID.randomUUID().toString());
		return purchaseRepo.save(purchase);
	}

	public PurchaseHistory getReceipt(String id) {
		return purchaseRepo.findById(id).orElseThrow(() -> new BookNotFoundException("Transaction with id: "+ id +" not found."));
	}
	
	

}
